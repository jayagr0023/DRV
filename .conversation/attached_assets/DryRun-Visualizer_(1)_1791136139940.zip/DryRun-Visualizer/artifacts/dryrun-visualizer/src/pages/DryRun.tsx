import { type KeyboardEvent, useEffect, useMemo, useState } from 'react';
import { Link } from 'wouter';
import {
  AlertCircle, Braces, Check, ChevronLeft, ChevronRight,
  CircleHelp, Cpu, Database, FileCode2, Layers3, Moon, Play,
  RotateCcw, Sun, Terminal, Volume2, Workflow,
} from 'lucide-react';
import { useCreateTrace, useGetDryRunHealth, useListLanguages } from '@workspace/api-client-react';
import type { TraceDocument, StoredTraceStep, TraceStep, ValueRef, HeapObject } from '@workspace/api-client-react';
import type { ThemeChoice } from '@/App';

const starterCode = `public class Main {
    static int factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }

    public static void main(String[] args) {
        int answer = factorial(4);
        System.out.println(answer);
    }
}`;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function valueText(value: ValueRef | unknown): string {
  if (!isRecord(value)) return String(value ?? '—');
  if (value.kind === 'prim') return String(value.value);
  if (value.kind === 'ref') return `↗ ${String(value.id)}`;
  if (value.kind === null) return 'null';
  if (value.kind === 'uninitialized') return 'not initialized';
  return '—';
}

function Header({ theme, setTheme }: { theme: ThemeChoice; setTheme: (theme: ThemeChoice) => void }) {
  return (
    <header className="topbar">
      <Link href="/" className="brand" aria-label="DryRun Visualizer home">
        <span className="brand-mark"><Workflow size={19} aria-hidden="true" /></span>
        <span>dryrun<span className="brand-sub"> / visualizer</span></span>
      </Link>
      <div className="header-actions">
        <Link href="/design" className="link-subtle" data-testid="link-design-review">Design review</Link>
        <div className="theme-switch" role="group" aria-label="Color theme">
          {([
            ['light', Sun, 'Light'],
            ['dark', Moon, 'Dark'],
            ['system', Cpu, 'System'],
          ] as const).map(([value, Icon, label]) => (
            <button key={value} type="button" onClick={() => setTheme(value)} aria-pressed={theme === value} aria-label={`${label} theme`} data-testid={`theme-${value}`}>
              <Icon size={14} aria-hidden="true" /><span>{label}</span>
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}

function EmptyPanel({ icon: Icon, children }: { icon: typeof CircleHelp; children: string }) {
  return <div className="empty-panel"><Icon size={15} aria-hidden="true" /><span>{children}</span></div>;
}

function InspectorPanel({
  snapshot,
  storage,
}: {
  snapshot: TraceStep | null;
  storage: 'keyframe' | 'delta' | null;
}) {
  const stateHint = storage === 'delta'
    ? 'This stored step is a delta. State snapshots are intentionally not reconstructed from patches.'
    : 'No execution state yet. Run the Java program to see the trace.';

  return (
    <div className="lower-grid">
      <section className="panel compact-panel" aria-labelledby="variables-heading">
        <div className="panel-head"><div><h2 className="panel-title" id="variables-heading"><Braces size={16} /> Variables</h2><div className="panel-kicker">Selected keyframe · current method</div></div></div>
        <div className="panel-content">
          {snapshot ? snapshot.stack.at(-1) && Object.keys(snapshot.stack.at(-1)!.locals).length ? Object.entries(snapshot.stack.at(-1)!.locals).map(([name, value]) => (
            <div className="data-row" key={name}><span className="data-key">{name}</span><span className="data-value">{valueText(value)}</span></div>
          )) : <EmptyPanel icon={Braces}>No local variables are present in this frame.</EmptyPanel> : <EmptyPanel icon={Braces}>{stateHint}</EmptyPanel>}
        </div>
      </section>
      <section className="panel compact-panel" aria-labelledby="stack-heading">
        <div className="panel-head"><div><h2 className="panel-title" id="stack-heading"><Layers3 size={16} /> Call stack</h2><div className="panel-kicker">Recursive calls stay visible</div></div>{snapshot?.stackTruncated ? <span className="pill">+{snapshot.stackTruncated} hidden</span> : null}</div>
        <div className="panel-content">
          {snapshot ? snapshot.stack.length ? [...snapshot.stack].reverse().map((frame, index) => (
            <div className="data-row" key={`${frame.class}-${frame.method}-${index}`}><span className="data-key">#{snapshot.stack.length - index}</span><span className="data-value">{frame.class}.{frame.method}()<small style={{ display: 'block', color: 'var(--muted-foreground)', marginTop: 4 }}>{frame.line === null ? 'line unavailable' : `line ${frame.line}`}</small></span></div>
          )) : <EmptyPanel icon={Layers3}>The selected keyframe has an empty call stack.</EmptyPanel> : <EmptyPanel icon={Layers3}>{stateHint}</EmptyPanel>}
        </div>
      </section>
      <section className="panel compact-panel" aria-labelledby="heap-heading">
        <div className="panel-head"><div><h2 className="panel-title" id="heap-heading"><Database size={16} /> Heap</h2><div className="panel-kicker">Objects referenced by the program</div></div></div>
        <div className="panel-content">
          {snapshot ? Object.keys(snapshot.heap).length ? Object.values(snapshot.heap).map((item: HeapObject) => (
            <div className="data-row" key={item.id}><span className="data-key">{item.id}</span><span className="data-value">{item.type} · {item.size} {item.size === 1 ? 'item' : 'items'}{item.truncated ? ' · truncated' : ''}</span></div>
          )) : <EmptyPanel icon={Database}>No heap objects in this keyframe.</EmptyPanel> : <EmptyPanel icon={Database}>{stateHint}</EmptyPanel>}
        </div>
      </section>
      <section className="panel compact-panel" aria-labelledby="output-heading">
        <div className="panel-head"><div><h2 className="panel-title" id="output-heading"><Terminal size={16} /> Program output</h2><div className="panel-kicker">Output reported at selected event</div></div></div>
        <div className="panel-content">
          {snapshot ? snapshot.stdout || snapshot.stderr ? <pre className="output-pre" aria-label="Trace output">{snapshot.stdout}{snapshot.stderr ? `\n${snapshot.stderr}` : ''}</pre> : <EmptyPanel icon={Terminal}>No output was reported at this step.</EmptyPanel> : <EmptyPanel icon={Terminal}>{stateHint}</EmptyPanel>}
        </div>
      </section>
    </div>
  );
}

function parseEvent(step: StoredTraceStep): { stepNo: number; event: string; line: number | null; explanation: string; changed: string[]; snapshot: TraceStep | null } {
  if (step.storage === 'keyframe') {
    return { stepNo: step.snapshot.step, event: step.snapshot.event, line: step.snapshot.line, explanation: step.snapshot.explanation, changed: step.snapshot.changed, snapshot: step.snapshot };
  }
  return { stepNo: step.step, event: step.event, line: step.line, explanation: step.explanation, changed: step.changed, snapshot: null };
}

export default function DryRun({ theme, setTheme }: { theme: ThemeChoice; setTheme: (theme: ThemeChoice) => void }) {
  const health = useGetDryRunHealth();
  const languages = useListLanguages();
  // Ask for the document response rather than the endpoint's default NDJSON stream.
  const createTrace = useCreateTrace({ request: { headers: { Accept: 'application/json' } } });
  const [code, setCode] = useState(starterCode);
  const [stdin, setStdin] = useState('');
  const [trace, setTrace] = useState<TraceDocument | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState('1');
  const [responseError, setResponseError] = useState('');
  const language = languages.data?.languages.find((item) => item.id.toLowerCase() === 'java' || item.displayName.toLowerCase() === 'java');
  const steps = trace?.steps ?? [];
  const selected = steps[activeIndex] ? parseEvent(steps[activeIndex]) : null;
  const canRun = !!language && !languages.isLoading && !createTrace.isPending && code.trim().length > 0 && code.length <= 20000;
  const lineCount = useMemo(() => Math.max(1, code.split('\n').length), [code]);

  useEffect(() => {
    if (!isPlaying || steps.length < 1) return undefined;
    const timer = window.setInterval(() => {
      setActiveIndex((index) => {
        if (index >= steps.length - 1) { setIsPlaying(false); return index; }
        return index + 1;
      });
    }, Math.max(250, 920 / Number(speed)));
    return () => window.clearInterval(timer);
  }, [isPlaying, speed, steps.length]);

  async function handleRun() {
    if (!canRun || !language) return;
    setResponseError('');
    setTrace(null);
    setActiveIndex(0);
    setIsPlaying(false);
    try {
      const result = await createTrace.mutateAsync({
        data: { schemaVersion: '1.0.0', language: language.id, code, stdin },
      });
      let parsed: unknown = result;
      if (typeof Response !== 'undefined' && result instanceof Response) {
        if (!result.ok) throw new Error(`Trace service returned HTTP ${result.status}.`);
        parsed = await result.json();
      }
      if (!isRecord(parsed) || !Array.isArray(parsed.steps) || !isRecord(parsed.end)) {
        throw new Error('The trace service response did not contain a TraceDocument. No sample data was substituted.');
      }
      setTrace(parsed as unknown as TraceDocument);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'The trace request could not be completed.';
      setResponseError(message);
    }
  }

  function editCode(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key !== 'Tab') return;
    event.preventDefault();
    const element = event.currentTarget;
    const start = element.selectionStart;
    const end = element.selectionEnd;
    const next = `${code.slice(0, start)}    ${code.slice(end)}`;
    setCode(next);
    requestAnimationFrame(() => { element.selectionStart = element.selectionEnd = start + 4; });
  }

  const isHealthy = health.data?.status === 'ok';
  const status = trace?.end.status;

  return (
    <div className="app-shell">
      <Header theme={theme} setTheme={setTheme} />
      <main className="workspace">
        <div className="intro-row">
          <div><div className="eyebrow">Learn by stepping through</div><h1 className="page-title">See what Java is doing.</h1><p className="lede">Run a small program, then follow variables, calls, objects, and output as execution unfolds.</p></div>
          <div className="health-pill" role="status" data-testid="status-api-health">
            {health.isLoading ? <span className="health-dot warn" /> : <span className={`health-dot${isHealthy ? '' : ' warn'}`} />}
            {health.isLoading ? 'Checking trace service' : health.isError ? 'Service status unavailable' : isHealthy ? 'Trace service ready' : 'Trace service degraded'}
          </div>
        </div>

        {health.isError && <div className="error-banner" role="alert">Could not check the trace service. You can edit code, but a trace will only be created if the Java service is reachable.</div>}
        {languages.isError && <div className="error-banner" role="alert">Supported languages could not be loaded. Java availability is unknown, so running is disabled until the API responds.</div>}
        {!languages.isLoading && languages.data && !language && <div className="error-banner" role="alert">No sandboxed Java runner is available yet. You can edit your program and input, but tracing stays disabled so code is never run inside the API service.</div>}

        <div className="workspace-grid" style={{ marginTop: 20 }}>
          <section aria-labelledby="editor-heading">
            <div className="panel-head" style={{ paddingLeft: 3, paddingRight: 3 }}>
              <div><h2 className="panel-title" id="editor-heading"><FileCode2 size={17} /> Your program</h2><div className="panel-kicker">Java · edit, then run against the trace service</div></div>
              <span className="pill">.java</span>
            </div>
            <div className="code-panel">
              <div className="code-top"><span className="code-badge"><span className="code-dot" /> Main.java</span><span>Java source</span></div>
              <div className="editor-wrap">
                <div className="line-numbers" aria-hidden="true">{Array.from({ length: lineCount }, (_, index) => index + 1).join('\n')}</div>
                <textarea className="code-editor" aria-label="Java source code" spellCheck={false} value={code} onChange={(event) => setCode(event.target.value)} onKeyDown={editCode} data-testid="input-java-code" />
              </div>
              <div className="editor-foot"><span>Tab inserts 4 spaces</span><span>{code.length.toLocaleString()} / 20,000 chars</span></div>
            </div>
            <div className="stdin-wrap">
              <label htmlFor="stdin" className="field-label">Standard input <span style={{ fontWeight: 400 }}>(optional)</span></label>
              <textarea id="stdin" className="stdin-input" value={stdin} onChange={(event) => setStdin(event.target.value)} rows={2} maxLength={5000} placeholder="Text your program reads from System.in" data-testid="input-stdin" />
            </div>
            <div className="form-actions">
              <span className="subtle-note">Each run is sent to the Java trace endpoint.<br />Execution data appears only after a successful response.</span>
              <button className="primary-button" type="button" onClick={handleRun} disabled={!canRun} data-testid="button-run-trace">
                {createTrace.isPending ? <><RotateCcw size={16} className="animate-spin" /> Tracing…</> : <><Play size={15} fill="currentColor" /> Run trace</>}
              </button>
            </div>
            {createTrace.isError && <div className="error-banner" role="alert" data-testid="error-trace-request"><AlertCircle size={14} style={{ verticalAlign: '-3px', marginRight: 6 }} />{String((createTrace.error as { message?: string } | null)?.message || 'The trace request failed. Check that the API service is available, then try again.')}</div>}
            {responseError && <div className="error-banner" role="alert" data-testid="error-trace-response">{responseError}</div>}
            {code.length > 20000 && <div className="error-banner" role="alert">Java source is over the 20,000 character limit.</div>}
          </section>

          <div className="results-column" aria-label="Execution trace panels">
            <section className="panel explain-panel" aria-labelledby="explanation-heading">
              <div className="panel-head"><div><h2 className="panel-title" id="explanation-heading"><CircleHelp size={17} /> What just happened?</h2><div className="panel-kicker">A plain-language guide to the selected event</div></div>
                {selected ? <span className={`semantic-tag ${selected.event}`}><span aria-hidden="true">●</span>{selected.event}</span> : <span className="pill">Waiting for a run</span>}
              </div>
              <div className="explain-body" aria-live="polite" data-testid="text-step-explanation">
                {selected ? <>{selected.explanation}<div className="trace-meta"><span>Step {selected.stepNo}</span><span aria-hidden="true">·</span><span>{selected.line === null ? 'No source line' : `Line ${selected.line}`}</span><span aria-hidden="true">·</span><span>{selected.changed.length ? `${selected.changed.length} changed ${selected.changed.length === 1 ? 'value' : 'values'}` : 'No recorded changes'}</span></div></> : trace ? 'The trace has no executable steps. Review service diagnostics below.' : 'This space will explain the exact event you select. Nothing runs until you ask for a trace.'}
              </div>
            </section>

            <section className="panel" aria-labelledby="timeline-heading">
              <div className="panel-head"><div><h2 className="panel-title" id="timeline-heading"><Workflow size={16} /> Execution steps</h2><div className="panel-kicker">{trace ? `${steps.length} stored events · ${trace.languageVersion}` : 'The trace timeline appears after a successful run'}</div></div>{trace && <span className="pill" data-testid="text-step-total">{steps.length} steps</span>}</div>
              {trace ? steps.length ? <div className="trace-list" role="list" aria-label="Trace steps">
                {steps.map((stored, index) => {
                  const item = parseEvent(stored);
                  return <button key={`${item.stepNo}-${index}`} className="trace-step" type="button" aria-current={activeIndex === index} aria-label={`Step ${item.stepNo}, ${item.event}${item.line === null ? '' : `, line ${item.line}`}`} onClick={() => { setActiveIndex(index); setIsPlaying(false); }} data-testid={`button-step-${index}`}>
                    <b>{String(item.stepNo).padStart(2, '0')}</b><small>{item.event}{stored.storage === 'delta' ? ' · delta' : ' · keyframe'}</small>
                  </button>;
                })}
              </div> : <div className="panel-content"><EmptyPanel icon={Workflow}>The service returned a trace with no steps.</EmptyPanel></div> : <div className="panel-content"><EmptyPanel icon={Workflow}>No execution data yet. Your code is not interpreted in the browser.</EmptyPanel></div>}
              {trace && <div className="trace-status" role="status" data-testid="status-trace-end">
                {status === 'ok' ? <Check size={14} color="#268a6c" /> : <AlertCircle size={14} color="#c45d55" />}
                <span>Trace ended: <strong>{status?.replace('_', ' ')}</strong></span>
                {trace.end.diagnostics.length > 0 && <span>· {trace.end.diagnostics.length} diagnostic{trace.end.diagnostics.length === 1 ? '' : 's'}</span>}
              </div>}
            </section>
            {trace?.end.diagnostics.map((diagnostic, index) => <div className="error-banner" key={`${diagnostic.severity}-${index}`} role="status">{diagnostic.line !== null ? `Line ${diagnostic.line}: ` : ''}{diagnostic.message}</div>)}
            <InspectorPanel snapshot={selected?.snapshot ?? null} storage={selected ? (steps[activeIndex].storage as 'keyframe' | 'delta') : null} />
          </div>
        </div>
      </main>
      <div className="dock" role="group" aria-label="Trace playback controls">
        <div className="dock-inner">
          <button className="dock-button" type="button" title="Previous step" aria-label="Previous step" disabled={!steps.length || activeIndex === 0} onClick={() => { setIsPlaying(false); setActiveIndex((index) => Math.max(0, index - 1)); }} data-testid="button-previous"><ChevronLeft size={18} /></button>
          <button className="dock-button play" type="button" title={isPlaying ? 'Pause trace' : 'Play trace'} aria-label={isPlaying ? 'Pause trace' : 'Play trace'} disabled={!steps.length} onClick={() => setIsPlaying((playing) => !playing)} data-testid="button-play-pause">{isPlaying ? <span aria-hidden="true">Ⅱ</span> : <Play size={18} fill="currentColor" />}</button>
          <button className="dock-button" type="button" title="Next step" aria-label="Next step" disabled={!steps.length || activeIndex >= steps.length - 1} onClick={() => { setIsPlaying(false); setActiveIndex((index) => Math.min(steps.length - 1, index + 1)); }} data-testid="button-next"><ChevronRight size={18} /></button>
          <span className="dock-position" aria-live="polite" data-testid="text-current-position">{steps.length ? `${activeIndex + 1} / ${steps.length}` : '— / —'}</span>
          <label className="speed-control"><Volume2 size={14} /><span>Speed</span><select aria-label="Playback speed" value={speed} onChange={(event) => setSpeed(event.target.value)} data-testid="select-playback-speed"><option value="0.5">0.5×</option><option value="1">1×</option><option value="2">2×</option></select></label>
          <button className="dock-button" type="button" title="Jump to first step" aria-label="Jump to first step" disabled={!steps.length || activeIndex === 0} onClick={() => { setIsPlaying(false); setActiveIndex(0); }} data-testid="button-first"><RotateCcw size={16} /></button>
        </div>
      </div>
    </div>
  );
}